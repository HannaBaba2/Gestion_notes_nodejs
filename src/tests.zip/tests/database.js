import sqlite3 from 'sqlite3'

import {open} from 'sqlite'

export async function openDb() {
    return open({

        filename:'/home/hanna-traore/Dossier_L3/Node_Js/gestion_notes/src/tests/database.sqlite3',
        driver:sqlite3.Database 
    })
}

const db=await openDb();
// console.log(db);

const ddl=`

CREATE TABLE IF NOT EXISTS students(

    id INTEGER PRIMARY KEY autoincrement,
    firsname TEXT,
    lastname TEXT,
    sexe TEXT,
    birth_day DATE,
    check(sexe in('M','F'))

);

`
;


const dml=`

    INSERT INTO students(firsname,lastname,sexe,birth_day)
    VALUES ('BABA','Hanna','F','1998/01/02'),
           ('NAZEGA','Yuyiu','M','1998/01/02'),
           ('ABALO','ABlo','M','1998/01/02'),
           ('DADO','Jean','F','1998/01/02');

`
;
await db.exec(ddl);
await db.exec(dml);